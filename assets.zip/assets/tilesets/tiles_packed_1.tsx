<?xml version="1.0" encoding="UTF-8"?>
<tileset name="tiles_packed_1" tilewidth="16" tileheight="16" tilecount="184" columns="23">
 <image source="tiles_packed_1.png" width="368" height="128"/>
</tileset>
